import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        nexus: { bg: "#07060f", panel: "#0f0d1f", line: "#2a2552", violet: "#8b5cf6", blue: "#2f6bff", cyan: "#22d3ee" }
      },
      fontFamily: {
        head: ["var(--font-head)", "system-ui", "sans-serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"]
      },
      boxShadow: { neon: "0 0 22px rgba(139,92,246,.45)" }
    }
  },
  plugins: []
};
export default config;
