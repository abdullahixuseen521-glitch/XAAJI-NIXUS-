"use client";
import { createContext, ReactNode, useCallback, useContext, useEffect, useState } from "react";

const so = {
  nav_home: "Hoyga", nav_chat: "AI Wadahadal", nav_games: "Ciyaaraha", nav_learn: "Waxbarasho", nav_studio: "Qalabka Abuurka",
  nav_notes: "Buug-yare", nav_support: "Taageero", nav_admin: "Maamule",
  login: "Gal", register: "Isdiiwaangeli", logout: "Ka bax", account: "Akoonkayga",
  hero_cta_chat: "Bilow AI", hero_cta_games: "Ciyaar",
  welcome_default: "ASC! Ku soo dhawoow XAAJI NEXUS AI 🚀 Halkaan waxaad ka heli kartaa AI, ciyaaro, waxbarasho iyo qalab kaa caawinaya inaad fikradahaaga u beddesho wax dhab ah.",
  feat_chat: "La hadal AI-ga, weydii wax kasta oo hel jawaab degdeg ah.",
  feat_games: "Tic-Tac-Toe, Memory Match iyo Snake oo leh dhibco.",
  feat_learn: "Casharro ku saabsan muuqaalka, AI, website-ka iyo barnaamijka.",
  feat_studio: "Samee prompts muuqaal, fikrado iyo qoraallo bulsho.",
  feat_notes: "Qoraalladaada gaarka ah, la raadin karo oo la kaydiyo.",
  feat_support: "Nala soo xiriir, waan ku caawinaynaa.",
  loading: "Waa la rarayaa…", error_generic: "Wax khalad ah ayaa dhacay. Fadlan mar kale isku day.",
  need_login: "Fadlan marka hore gal akoonkaaga.", save: "Kaydi", delete: "Tirtir", cancel: "Jooji", edit: "Wax ka beddel",
  search: "Raadi", all: "Dhammaan", send: "Dir", restart: "Dib u bilow", copy: "Koobiyee", copied: "La koobiyeeyay ✓",
  back: "Dib u laabo", empty: "Weli waxba ma jiraan.", saved: "Waa la kaydiyay ✓",
  chat_new: "Wadahadal cusub", chat_clear: "Nadiifi wadahadalka", chat_ph: "Qor su'aashaada…",
  chat_empty: "Weydii wax kasta. AI-gu wuxuu ku jawaabi doonaa luuqaddaada.", chat_history: "Taariikhda",
  chat_thinking: "AI-gu wuu fikiraa…", chat_delete: "Tirtir wadahadalka",
  score: "Dhibco", moves: "Dhaqdhaqaaqyo", time: "Waqti", leaderboard: "Liiska hormarka", game_over: "Ciyaarta way dhammaatay",
  you_win: "Waad guuleysatay!", you_lose: "Waad lumisay", draw: "Barbaro", login_to_save: "Gal si dhibcahaaga loo kaydiyo.",
  score_saved: "Dhibcaha waa la kaydiyay ✓", start: "Bilow", no_scores: "Weli dhibco ma jiraan.",
  g_ttt: "Tic-Tac-Toe", g_memory: "Memory Match", g_snake: "Snake",
  progress: "Horumar", steps: "Tallaabooyin", lessons_empty: "Weli casharro ma jiraan.", video: "Muuqaal",
  st_prompt: "Prompt Muuqaal", st_ideas: "Fikrado", st_captions: "Captions", st_desc: "Sharraxaad Bulsho",
  topic: "Mawduuc", characters: "Jilayaasha", location: "Goob", language: "Luuqad", style: "Qaab", generate: "Samee",
  text_only: "Qoraal keliya: qalabkani ma abuuro muuqaal dhab ah.", ai_text_note: "Qoraalkan waxaa soo saaray AI. Wuxuu u baahan yahay gelitaan.",
  n_title: "Cinwaan", n_body: "Qoraal", n_category: "Qeyb", n_new: "Qoraal cusub", updated: "La cusboonaysiiyay",
  c_personal: "Shakhsi", c_school: "Dugsi", c_work: "Shaqo", c_ideas: "Fikrado",
  email: "Email", password: "Erayga sirta ah", name: "Magaca", no_account: "Akoon ma lihid?", have_account: "Akoon ma leedahay?",
  check_email: "Fiiri emailkaaga si aad u xaqiijiso akoonka.", pw_hint: "Ugu yaraan 8 xaraf.",
  sp_message: "Fariinta", sp_send: "Dir fariinta", sp_sending: "Waa la dirayaa…", sp_ok: "Fariinta waa la helay. Mahadsanid!",
  sp_whatsapp: "WhatsApp Taageero", sp_wa_missing: "Lambarka WhatsApp weli lama dejin.",
  acc_lang: "Luuqadda la door bidayo",
  ad_lessons: "Casharro", ad_users: "Isticmaalayaal", ad_messages: "Fariimaha", ad_content: "Nuxur"
} as const;

export type Key = keyof typeof so;

const en: Record<Key, string> = {
  nav_home: "Home", nav_chat: "AI Chat", nav_games: "Games", nav_learn: "Learn", nav_studio: "Creator Studio",
  nav_notes: "Notebook", nav_support: "Support", nav_admin: "Admin",
  login: "Log in", register: "Sign up", logout: "Log out", account: "My account",
  hero_cta_chat: "Start with AI", hero_cta_games: "Play",
  welcome_default: "Welcome to XAAJI NEXUS AI 🚀 Here you will find AI, games, learning and tools that help you turn your ideas into real things.",
  feat_chat: "Talk to AI, ask anything and get fast answers.",
  feat_games: "Tic-Tac-Toe, Memory Match and Snake with scores.",
  feat_learn: "Lessons on video, AI, websites and programming.",
  feat_studio: "Build video prompts, ideas and social posts.",
  feat_notes: "Your private notes, searchable and saved.",
  feat_support: "Contact us. We are happy to help.",
  loading: "Loading…", error_generic: "Something went wrong. Please try again.",
  need_login: "Please log in first.", save: "Save", delete: "Delete", cancel: "Cancel", edit: "Edit",
  search: "Search", all: "All", send: "Send", restart: "Restart", copy: "Copy", copied: "Copied ✓",
  back: "Back", empty: "Nothing here yet.", saved: "Saved ✓",
  chat_new: "New conversation", chat_clear: "Clear chat", chat_ph: "Type your question…",
  chat_empty: "Ask anything. The AI replies in your language.", chat_history: "History",
  chat_thinking: "AI is thinking…", chat_delete: "Delete conversation",
  score: "Score", moves: "Moves", time: "Time", leaderboard: "Leaderboard", game_over: "Game over",
  you_win: "You win!", you_lose: "You lost", draw: "Draw", login_to_save: "Log in to save your score.",
  score_saved: "Score saved ✓", start: "Start", no_scores: "No scores yet.",
  g_ttt: "Tic-Tac-Toe", g_memory: "Memory Match", g_snake: "Snake",
  progress: "Progress", steps: "Steps", lessons_empty: "No lessons yet.", video: "Video",
  st_prompt: "Video Prompt", st_ideas: "Ideas", st_captions: "Captions", st_desc: "Social Post",
  topic: "Topic", characters: "Characters", location: "Location", language: "Language", style: "Style", generate: "Generate",
  text_only: "Text only: this tool does not create an actual video.", ai_text_note: "This text is written by AI and requires you to be logged in.",
  n_title: "Title", n_body: "Note", n_category: "Category", n_new: "New note", updated: "Updated",
  c_personal: "Personal", c_school: "School", c_work: "Work", c_ideas: "Ideas",
  email: "Email", password: "Password", name: "Name", no_account: "No account yet?", have_account: "Already have an account?",
  check_email: "Check your email to confirm your account.", pw_hint: "At least 8 characters.",
  sp_message: "Message", sp_send: "Send message", sp_sending: "Sending…", sp_ok: "Your message was received. Thank you!",
  sp_whatsapp: "WhatsApp support", sp_wa_missing: "The WhatsApp number is not configured yet.",
  acc_lang: "Preferred language",
  ad_lessons: "Lessons", ad_users: "Users", ad_messages: "Messages", ad_content: "Content"
};

export type Lang = "so" | "en";
const D: Record<Lang, Record<Key, string>> = { so, en };

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: (k: Key) => string };
const LangCtx = createContext<Ctx>({ lang: "so", setLang: () => {}, t: (k) => so[k] });

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setL] = useState<Lang>("so");
  useEffect(() => {
    const saved = localStorage.getItem("lang");
    if (saved === "so" || saved === "en") setL(saved);
  }, []);
  useEffect(() => { document.documentElement.lang = lang; }, [lang]);
  const setLang = useCallback((l: Lang) => { setL(l); localStorage.setItem("lang", l); }, []);
  const t = useCallback((k: Key) => D[lang][k], [lang]);
  return <LangCtx.Provider value={{ lang, setLang, t }}>{children}</LangCtx.Provider>;
}
export const useLang = () => useContext(LangCtx);
