export type AIMode = "chat" | "ideas" | "captions" | "descriptions";
export class AIConfigError extends Error {}

const lang = (l: "so" | "en") => (l === "so" ? "Somali" : "English");

export function systemPrompt(mode: AIMode, l: "so" | "en"): string {
  const base = `You are XAAJI NEXUS AI, a friendly assistant inside a learning and creator app. Write in ${lang(l)} unless the user clearly writes in another language.`;
  switch (mode) {
    case "ideas":
      return `${base} Give 6 short, practical video ideas as a numbered list. Each idea: a hook line and one sentence on what to show. Output text only.`;
    case "captions":
      return `${base} Write 5 short social media captions with fitting emojis and 3-5 hashtags each. Output text only.`;
    case "descriptions":
      return `${base} Write one social media post description (60-120 words) with a call to action and 5 hashtags. Output text only.`;
    default:
      return `${base} Be clear, accurate and concise. If you are unsure, say so instead of guessing.`;
  }
}

export async function askClaude(system: string, messages: { role: "user" | "assistant"; content: string }[]) {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new AIConfigError("ANTHROPIC_API_KEY is not set");
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5", max_tokens: 1024, system, messages })
  });
  if (!res.ok) throw new Error(`AI provider error ${res.status}`);
  const data = (await res.json()) as { content?: { type: string; text?: string }[] };
  const text = (data.content ?? []).filter((b) => b.type === "text").map((b) => b.text ?? "").join("\n").trim();
  if (!text) throw new Error("Empty AI response");
  return text;
}
