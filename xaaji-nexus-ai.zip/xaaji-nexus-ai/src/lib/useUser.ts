"use client";
import { useEffect, useState } from "react";
import type { User } from "@supabase/supabase-js";
import { supabaseBrowser } from "./supabase/client";

export type Profile = { id: string; display_name: string | null; role: "user" | "admin"; lang: "so" | "en" };

export function useUser() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const sb = supabaseBrowser();
    const load = async (u: User | null) => {
      setUser(u);
      if (u) {
        const { data } = await sb.from("profiles").select("id,display_name,role,lang").eq("id", u.id).single();
        setProfile((data as Profile) ?? null);
      } else setProfile(null);
      setLoading(false);
    };
    sb.auth.getUser().then(({ data }) => load(data.user));
    const { data: sub } = sb.auth.onAuthStateChange((_e, session) => {
      setTimeout(() => load(session?.user ?? null), 0);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  return { user, profile, loading };
}
