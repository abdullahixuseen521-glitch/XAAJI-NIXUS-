"use client";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { useLang } from "@/lib/i18n";
import { supabaseBrowser } from "@/lib/supabase/client";

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const { t } = useLang();
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next");
  const dest = next && next.startsWith("/") && !next.startsWith("//") ? next : "/";
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(""); setInfo(""); setBusy(true);
    const sb = supabaseBrowser();
    try {
      if (mode === "login") {
        const { error } = await sb.auth.signInWithPassword({ email, password });
        if (error) throw error;
        router.push(dest); router.refresh();
      } else {
        const { data, error } = await sb.auth.signUp({
          email, password, options: { data: { display_name: name.trim() }, emailRedirectTo: `${location.origin}/login` }
        });
        if (error) throw error;
        if (data.session) { router.push(dest); router.refresh(); } else setInfo(t("check_email"));
      }
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : t("error_generic"));
    } finally { setBusy(false); }
  }

  return (
    <div className="page max-w-md">
      <h1 className="h1 mb-4">{mode === "login" ? t("login") : t("register")}</h1>
      <form onSubmit={submit} className="card space-y-4">
        {mode === "register" && (
          <div><label className="label" htmlFor="name">{t("name")}</label><input id="name" className="input" required maxLength={60} autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} /></div>
        )}
        <div><label className="label" htmlFor="email">{t("email")}</label><input id="email" type="email" className="input" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></div>
        <div><label className="label" htmlFor="pw">{t("password")}</label>
          <input id="pw" type="password" className="input" required minLength={8} autoComplete={mode === "login" ? "current-password" : "new-password"} value={password} onChange={(e) => setPassword(e.target.value)} />
          {mode === "register" && <p className="mt-1 text-xs text-slate-400">{t("pw_hint")}</p>}</div>
        {err && <p className="alert-err">{err}</p>}
        {info && <p className="alert-ok">{info}</p>}
        <button className="btn w-full" disabled={busy}>{busy ? t("loading") : mode === "login" ? t("login") : t("register")}</button>
        <p className="text-center text-sm text-slate-300">
          {mode === "login" ? <>{t("no_account")} <Link className="underline" href="/register">{t("register")}</Link></> : <>{t("have_account")} <Link className="underline" href="/login">{t("login")}</Link></>}
        </p>
      </form>
    </div>
  );
}
