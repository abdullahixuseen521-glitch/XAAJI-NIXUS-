export default function Video({ url }: { url: string }) {
  let u: URL;
  try { u = new URL(url); } catch { return null; }
  if (u.protocol !== "https:") return null;
  const host = u.hostname.replace(/^www\./, "");
  let id = "";
  if (host === "youtu.be") id = u.pathname.slice(1);
  else if (host === "youtube.com") id = u.searchParams.get("v") ?? (u.pathname.startsWith("/embed/") ? u.pathname.split("/")[2] : "");
  if (/^[\w-]{11}$/.test(id))
    return <iframe className="aspect-video w-full rounded-xl" src={`https://www.youtube-nocookie.com/embed/${id}`} title="Lesson video" allowFullScreen loading="lazy" />;
  if (/\.(mp4|webm)$/i.test(u.pathname)) return <video className="aspect-video w-full rounded-xl" controls src={url} />;
  return <a className="btn-ghost" href={url} target="_blank" rel="noopener noreferrer">Open video</a>;
}
