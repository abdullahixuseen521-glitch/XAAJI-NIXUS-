"use client";
import { useEffect, useRef, useState } from "react";
import { useLang } from "@/lib/i18n";

const EMOJI = ["🚀", "🎮", "🧠", "🎬", "💡", "🌙", "⚡", "🎧"];
type Card = { id: number; e: string; open: boolean; done: boolean };
const deck = (): Card[] => [...EMOJI, ...EMOJI].sort(() => Math.random() - 0.5).map((e, id) => ({ id, e, open: false, done: false }));

export default function Memory({ onFinish }: { onFinish: (score: number) => void }) {
  const { t } = useLang();
  const [cards, setCards] = useState<Card[]>(deck);
  const [sel, setSel] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [secs, setSecs] = useState(0);
  const [running, setRunning] = useState(false);
  const [finished, setFinished] = useState<number | null>(null);
  const cb = useRef(onFinish); cb.current = onFinish;

  useEffect(() => {
    if (!running) return;
    const id = setInterval(() => setSecs((s) => s + 1), 1000);
    return () => clearInterval(id);
  }, [running]);

  function flip(id: number) {
    if (sel.length === 2 || finished !== null) return;
    const c = cards.find((x) => x.id === id)!;
    if (c.open || c.done) return;
    setRunning(true);
    const next = cards.map((x) => (x.id === id ? { ...x, open: true } : x));
    setCards(next);
    const s = [...sel, id];
    setSel(s);
    if (s.length === 2) {
      setMoves((m) => m + 1);
      const [a, b] = s.map((i) => next.find((x) => x.id === i)!);
      setTimeout(() => {
        const match = a.e === b.e;
        const after = next.map((x) => (s.includes(x.id) ? (match ? { ...x, done: true } : { ...x, open: false }) : x));
        setCards(after); setSel([]);
        if (after.every((x) => x.done)) {
          setRunning(false);
          const score = Math.max(50, Math.min(1000, 1000 - (moves + 1) * 20 - secs * 2));
          setFinished(score); cb.current(score);
        }
      }, 700);
    }
  }
  function restart() { setCards(deck()); setSel([]); setMoves(0); setSecs(0); setRunning(false); setFinished(null); }

  return (
    <div className="mx-auto max-w-sm text-center">
      <p className="mb-2 text-sm text-slate-300">{t("moves")}: <b>{moves}</b> · {t("time")}: <b>{secs}s</b>{finished !== null && <> · {t("score")}: <b>{finished}</b></>}</p>
      <div className="grid grid-cols-4 gap-2">
        {cards.map((c) => (
          <button key={c.id} onClick={() => flip(c.id)} aria-label="card"
            className={`aspect-square rounded-xl border text-3xl transition ${c.open || c.done ? "border-nexus-violet bg-nexus-violet/20" : "border-nexus-line bg-nexus-bg/70"}`}>
            {c.open || c.done ? c.e : ""}
          </button>
        ))}
      </div>
      {finished !== null && <p className="mt-3 font-semibold">{t("you_win")}</p>}
      <button onClick={restart} className="btn mt-3">{t("restart")}</button>
    </div>
  );
}
