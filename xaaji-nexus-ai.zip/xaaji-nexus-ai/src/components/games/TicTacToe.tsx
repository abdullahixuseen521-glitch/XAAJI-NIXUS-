"use client";
import { useState } from "react";
import { useLang } from "@/lib/i18n";

type Cell = "X" | "O" | null;
const LINES = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
const winner = (b: Cell[]): Cell => { for (const [a, c, d] of LINES) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a]; return null; };

function aiMove(b: Cell[]): number {
  const empty = b.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0);
  const find = (p: "X" | "O") => { for (const i of empty) { const c = [...b]; c[i] = p; if (winner(c) === p) return i; } return -1; };
  let m = find("O"); if (m >= 0) return m;
  m = find("X"); if (m >= 0 && Math.random() < 0.85) return m;
  if (!b[4] && Math.random() < 0.6) return 4;
  return empty[Math.floor(Math.random() * empty.length)];
}

export default function TicTacToe() {
  const { t } = useLang();
  const [board, setBoard] = useState<Cell[]>(Array(9).fill(null));
  const [status, setStatus] = useState<"play" | "win" | "lose" | "draw">("play");
  const [wait, setWait] = useState(false);
  const [score, setScore] = useState(0); // session score: win 3, draw 1

  function settle(b: Cell[]) {
    const w = winner(b);
    if (w === "X") { setStatus("win"); setScore((s) => s + 3); return true; }
    if (w === "O") { setStatus("lose"); return true; }
    if (b.every(Boolean)) { setStatus("draw"); setScore((s) => s + 1); return true; }
    return false;
  }
  function play(i: number) {
    if (board[i] || status !== "play" || wait) return;
    const nb = [...board]; nb[i] = "X"; setBoard(nb);
    if (settle(nb)) return;
    setWait(true);
    setTimeout(() => {
      const nb2 = [...nb]; nb2[aiMove(nb)] = "O"; setBoard(nb2); settle(nb2); setWait(false);
    }, 350);
  }
  const restart = () => { setBoard(Array(9).fill(null)); setStatus("play"); setWait(false); };
  const msg = { play: "", win: t("you_win"), lose: t("you_lose"), draw: t("draw") }[status];

  return (
    <div className="mx-auto max-w-xs text-center">
      <p className="mb-2 text-sm text-slate-300">{t("score")}: <b>{score}</b></p>
      <div className="grid grid-cols-3 gap-2">
        {board.map((c, i) => (
          <button key={i} onClick={() => play(i)} aria-label={`cell ${i + 1}`}
            className={`aspect-square rounded-xl border border-nexus-line bg-nexus-bg/70 font-head text-4xl font-bold ${c === "X" ? "text-nexus-cyan" : "text-nexus-violet"}`}>{c}</button>
        ))}
      </div>
      <p className="mt-3 h-6 font-semibold" aria-live="polite">{msg}</p>
      <button onClick={restart} className="btn mt-2">{t("restart")}</button>
    </div>
  );
}
