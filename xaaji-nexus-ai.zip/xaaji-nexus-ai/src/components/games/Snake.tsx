"use client";
import { useEffect, useReducer, useRef, useState } from "react";
import { useLang } from "@/lib/i18n";

const N = 16;
type P = { x: number; y: number };
const eq = (a: P, b: P) => a.x === b.x && a.y === b.y;
const rndFood = (s: P[]): P => {
  for (;;) { const f = { x: Math.floor(Math.random() * N), y: Math.floor(Math.random() * N) }; if (!s.some((p) => eq(p, f))) return f; }
};

export default function Snake({ onFinish }: { onFinish: (score: number) => void }) {
  const { t } = useLang();
  const [, force] = useReducer((x: number) => x + 1, 0);
  const [state, setState] = useState<"idle" | "run" | "over">("idle");
  const snake = useRef<P[]>([{ x: 8, y: 8 }, { x: 7, y: 8 }, { x: 6, y: 8 }]);
  const food = useRef<P>({ x: 12, y: 8 });
  const score = useRef(0);
  const dir = useRef<P>({ x: 1, y: 0 });
  const pending = useRef<P>({ x: 1, y: 0 });
  const touch = useRef<P | null>(null);
  const cb = useRef(onFinish); cb.current = onFinish;

  const turn = (x: number, y: number) => { if (x === -dir.current.x && y === -dir.current.y) return; pending.current = { x, y }; };

  function start() {
    snake.current = [{ x: 8, y: 8 }, { x: 7, y: 8 }, { x: 6, y: 8 }];
    food.current = rndFood(snake.current);
    score.current = 0; dir.current = { x: 1, y: 0 }; pending.current = { x: 1, y: 0 };
    setState("run"); force();
  }

  useEffect(() => {
    if (state !== "run") return;
    const id = setInterval(() => {
      dir.current = pending.current;
      const h = snake.current[0];
      const head = { x: h.x + dir.current.x, y: h.y + dir.current.y };
      if (head.x < 0 || head.y < 0 || head.x >= N || head.y >= N || snake.current.some((p) => eq(p, head))) {
        setState("over"); cb.current(score.current); return;
      }
      const ns = [head, ...snake.current];
      if (eq(head, food.current)) { score.current += 10; food.current = rndFood(ns); } else ns.pop();
      snake.current = ns; force();
    }, 130);
    return () => clearInterval(id);
  }, [state]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const m: Record<string, [number, number]> = { ArrowUp: [0, -1], w: [0, -1], ArrowDown: [0, 1], s: [0, 1], ArrowLeft: [-1, 0], a: [-1, 0], ArrowRight: [1, 0], d: [1, 0] };
      const v = m[e.key];
      if (v && state === "run") { e.preventDefault(); turn(v[0], v[1]); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [state]);

  const onTouchEnd = (e: React.TouchEvent) => {
    const s = touch.current; if (!s) return;
    const dx = e.changedTouches[0].clientX - s.x, dy = e.changedTouches[0].clientY - s.y;
    if (Math.max(Math.abs(dx), Math.abs(dy)) < 20) return;
    if (Math.abs(dx) > Math.abs(dy)) turn(dx > 0 ? 1 : -1, 0); else turn(0, dy > 0 ? 1 : -1);
  };

  const cells = [];
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const p = { x, y };
    const isHead = eq(snake.current[0], p);
    const isBody = !isHead && snake.current.some((s) => eq(s, p));
    const cls = isHead ? "bg-nexus-cyan" : isBody ? "bg-nexus-violet" : eq(food.current, p) ? "rounded-full bg-pink-400" : "bg-nexus-bg/60";
    cells.push(<div key={`${x}-${y}`} className={cls} />);
  }
  const Pad = ({ x, y, label }: { x: number; y: number; label: string }) => (
    <button className="btn-ghost h-12 w-12 text-lg" aria-label={label} onClick={() => turn(x, y)}>{label}</button>
  );

  return (
    <div className="mx-auto max-w-sm text-center">
      <p className="mb-2 text-sm text-slate-300">{t("score")}: <b>{score.current}</b></p>
      <div className="grid aspect-square w-full gap-px overflow-hidden rounded-xl border border-nexus-line bg-nexus-line" style={{ gridTemplateColumns: `repeat(${N}, 1fr)`, touchAction: "none" }}
        onTouchStart={(e) => { touch.current = { x: e.touches[0].clientX, y: e.touches[0].clientY }; }} onTouchEnd={onTouchEnd}>
        {cells}
      </div>
      {state === "over" && <p className="mt-3 font-semibold">{t("game_over")}</p>}
      <div className="mx-auto mt-3 grid w-40 grid-cols-3 gap-1 sm:hidden">
        <span /><Pad x={0} y={-1} label="↑" /><span />
        <Pad x={-1} y={0} label="←" /><Pad x={0} y={1} label="↓" /><Pad x={1} y={0} label="→" />
      </div>
      <button onClick={start} className="btn mt-3">{state === "idle" ? t("start") : t("restart")}</button>
    </div>
  );
}
