"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { LogOut, Menu, UserRound, X } from "lucide-react";
import { Key, useLang } from "@/lib/i18n";
import { useUser } from "@/lib/useUser";
import { supabaseBrowser } from "@/lib/supabase/client";

const LINKS: { href: string; k: Key }[] = [
  { href: "/", k: "nav_home" }, { href: "/chat", k: "nav_chat" }, { href: "/games", k: "nav_games" },
  { href: "/learn", k: "nav_learn" }, { href: "/studio", k: "nav_studio" }, { href: "/notes", k: "nav_notes" },
  { href: "/support", k: "nav_support" }
];

export default function Nav() {
  const { t, lang, setLang } = useLang();
  const { user, profile } = useUser();
  const path = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  useEffect(() => { setOpen(false); }, [path]);
  useEffect(() => { if (profile?.lang) setLang(profile.lang); }, [profile?.lang, setLang]);

  const links = profile?.role === "admin" ? [...LINKS, { href: "/admin", k: "nav_admin" as Key }] : LINKS;

  async function switchLang(l: "so" | "en") {
    setLang(l);
    if (user) await supabaseBrowser().from("profiles").update({ lang: l }).eq("id", user.id);
  }
  async function logout() {
    await supabaseBrowser().auth.signOut();
    router.push("/");
    router.refresh();
  }

  return (
    <header className="sticky top-0 z-40 border-b border-nexus-line bg-nexus-bg/85 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-3">
        <Link href="/" className="font-head text-lg font-bold tracking-wide logo-glow">XAAJI NEXUS AI</Link>
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
          {links.map((l) => (
            <Link key={l.href} href={l.href}
              className={`rounded-lg px-3 py-1.5 text-sm transition ${path === l.href ? "bg-nexus-violet/20 text-white" : "text-slate-300 hover:text-white"}`}>
              {t(l.k)}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <div className="flex overflow-hidden rounded-lg border border-nexus-line text-xs" role="group" aria-label="Language">
            {(["so", "en"] as const).map((l) => (
              <button key={l} onClick={() => switchLang(l)} aria-pressed={lang === l}
                className={`px-2.5 py-1.5 ${lang === l ? "bg-nexus-violet text-white" : "text-slate-300"}`}>{l.toUpperCase()}</button>
            ))}
          </div>
          {user ? (
            <>
              <Link href="/account" className="btn-ghost hidden sm:inline-flex" aria-label={t("account")}><UserRound size={16} /></Link>
              <button onClick={logout} className="btn-ghost hidden sm:inline-flex" aria-label={t("logout")}><LogOut size={16} /></button>
            </>
          ) : (
            <Link href="/login" className="btn hidden !py-1.5 text-sm sm:inline-flex">{t("login")}</Link>
          )}
          <button className="btn-ghost lg:hidden" onClick={() => setOpen(!open)} aria-expanded={open} aria-label="Menu">
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>
      {open && (
        <nav className="border-t border-nexus-line px-4 pb-4 lg:hidden" aria-label="Mobile">
          <div className="mx-auto flex max-w-6xl flex-col gap-1 pt-2">
            {links.map((l) => (
              <Link key={l.href} href={l.href} className={`rounded-lg px-3 py-2.5 ${path === l.href ? "bg-nexus-violet/20" : ""}`}>{t(l.k)}</Link>
            ))}
            {user ? (
              <>
                <Link href="/account" className="rounded-lg px-3 py-2.5">{t("account")}</Link>
                <button onClick={logout} className="rounded-lg px-3 py-2.5 text-left">{t("logout")}</button>
              </>
            ) : (
              <>
                <Link href="/login" className="rounded-lg px-3 py-2.5">{t("login")}</Link>
                <Link href="/register" className="rounded-lg px-3 py-2.5">{t("register")}</Link>
              </>
            )}
          </div>
        </nav>
      )}
    </header>
  );
}
