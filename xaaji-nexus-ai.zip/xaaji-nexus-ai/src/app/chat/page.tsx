"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { History, MessageSquarePlus, Send, Trash2 } from "lucide-react";
import { supabaseBrowser } from "@/lib/supabase/client";
import { useLang } from "@/lib/i18n";

type Msg = { id?: string; role: "user" | "assistant"; content: string };
type Conv = { id: string; title: string };

export default function ChatPage() {
  const { t, lang } = useLang();
  const sb = useMemo(() => supabaseBrowser(), []);
  const [convs, setConvs] = useState<Conv[]>([]);
  const [active, setActive] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [showList, setShowList] = useState(false);
  const end = useRef<HTMLDivElement>(null);

  const loadConvs = useCallback(async () => {
    const { data, error } = await sb.from("conversations").select("id,title").order("updated_at", { ascending: false });
    if (error) setErr(t("error_generic"));
    else setConvs(data ?? []);
  }, [sb, t]);

  useEffect(() => { loadConvs(); }, [loadConvs]);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, busy]);

  async function openConv(id: string) {
    setActive(id); setShowList(false); setErr("");
    const { data } = await sb.from("messages").select("id,role,content").eq("conversation_id", id).order("created_at");
    setMsgs((data as Msg[]) ?? []);
  }
  function newConv() { setActive(null); setMsgs([]); setErr(""); setShowList(false); }

  async function clearChat() {
    if (!active) return setMsgs([]);
    const { error } = await sb.from("messages").delete().eq("conversation_id", active);
    if (error) setErr(t("error_generic")); else setMsgs([]);
  }
  async function deleteConv() {
    if (!active) return;
    const { error } = await sb.from("conversations").delete().eq("id", active);
    if (error) return setErr(t("error_generic"));
    setConvs((c) => c.filter((x) => x.id !== active));
    newConv();
  }

  async function send(e: React.FormEvent) {
    e.preventDefault();
    const text = input.trim();
    if (!text || busy) return;
    setBusy(true); setErr(""); setInput("");
    try {
      let id = active;
      if (!id) {
        const { data, error } = await sb.from("conversations").insert({ title: text.slice(0, 50) }).select("id,title").single();
        if (error || !data) throw new Error(t("error_generic"));
        id = data.id; setActive(id); setConvs((c) => [data, ...c]);
      }
      const next: Msg[] = [...msgs, { role: "user", content: text }];
      setMsgs(next);
      const ins = await sb.from("messages").insert({ conversation_id: id, role: "user", content: text });
      if (ins.error) throw new Error(t("error_generic"));
      const res = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: "chat", lang, messages: next.slice(-20).map(({ role, content }) => ({ role, content })) })
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || t("error_generic"));
      setMsgs((m) => [...m, { role: "assistant", content: json.reply }]);
      await sb.from("messages").insert({ conversation_id: id, role: "assistant", content: json.reply });
      await sb.from("conversations").update({ updated_at: new Date().toISOString() }).eq("id", id);
    } catch (e2) {
      setErr(e2 instanceof Error ? e2.message : t("error_generic"));
    } finally { setBusy(false); }
  }

  return (
    <div className="page grid gap-4 lg:grid-cols-[260px_1fr]">
      <aside className={`card ${showList ? "block" : "hidden"} max-h-[70vh] overflow-y-auto lg:block`}>
        <button onClick={newConv} className="btn mb-3 w-full"><MessageSquarePlus size={16} />{t("chat_new")}</button>
        <h2 className="mb-2 text-sm text-slate-400">{t("chat_history")}</h2>
        {convs.length === 0 && <p className="text-sm text-slate-500">{t("empty")}</p>}
        <ul className="space-y-1">
          {convs.map((c) => (
            <li key={c.id}>
              <button onClick={() => openConv(c.id)} className={`w-full truncate rounded-lg px-3 py-2 text-left text-sm ${active === c.id ? "bg-nexus-violet/25" : "hover:bg-white/5"}`}>{c.title}</button>
            </li>
          ))}
        </ul>
      </aside>

      <section className="card flex h-[75vh] flex-col !p-0">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-nexus-line p-3">
          <button className="btn-ghost lg:hidden" onClick={() => setShowList(!showList)}><History size={16} />{t("chat_history")}</button>
          <div className="ml-auto flex gap-2">
            <button onClick={newConv} className="btn-ghost text-sm"><MessageSquarePlus size={15} />{t("chat_new")}</button>
            <button onClick={clearChat} className="btn-ghost text-sm" disabled={msgs.length === 0}>{t("chat_clear")}</button>
            {active && <button onClick={deleteConv} className="btn-ghost text-sm" aria-label={t("chat_delete")}><Trash2 size={15} /></button>}
          </div>
        </div>
        <div className="flex-1 space-y-3 overflow-y-auto p-4" aria-live="polite">
          {msgs.length === 0 && <p className="mt-10 text-center text-slate-400">{t("chat_empty")}</p>}
          {msgs.map((m, i) => (
            <div key={m.id ?? i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
              <p className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${m.role === "user" ? "bg-gradient-to-r from-nexus-violet to-nexus-blue text-white" : "border border-nexus-line bg-nexus-bg/70"}`}>{m.content}</p>
            </div>
          ))}
          {busy && <p className="text-sm text-slate-400">{t("chat_thinking")}</p>}
          <div ref={end} />
        </div>
        {err && <div className="alert-err mx-3">{err}</div>}
        <form onSubmit={send} className="flex gap-2 p-3">
          <input className="input" value={input} onChange={(e) => setInput(e.target.value)} placeholder={t("chat_ph")} maxLength={4000} aria-label={t("chat_ph")} />
          <button className="btn" disabled={busy || !input.trim()} aria-label={t("send")}><Send size={16} /></button>
        </form>
      </section>
    </div>
  );
}
