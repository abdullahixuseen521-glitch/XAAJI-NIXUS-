"use client";
import { useEffect, useState } from "react";
import { useLang } from "@/lib/i18n";
import { useUser } from "@/lib/useUser";
import { supabaseBrowser } from "@/lib/supabase/client";

export default function AccountPage() {
  const { t, setLang } = useLang();
  const { user, profile, loading } = useUser();
  const [name, setName] = useState("");
  const [lang, setL] = useState<"so" | "en">("so");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => { if (profile) { setName(profile.display_name ?? ""); setL(profile.lang); } }, [profile]);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!user) return;
    setMsg(""); setErr("");
    const { error } = await supabaseBrowser().from("profiles").update({ display_name: name.trim(), lang }).eq("id", user.id);
    if (error) return setErr(t("error_generic"));
    setLang(lang); setMsg(t("saved"));
  }
  if (loading) return <div className="page">{t("loading")}</div>;
  return (
    <div className="page max-w-md">
      <h1 className="h1 mb-4">{t("account")}</h1>
      <form onSubmit={save} className="card space-y-4">
        <p className="text-sm text-slate-400">{user?.email}</p>
        <div><label className="label" htmlFor="n">{t("name")}</label><input id="n" className="input" maxLength={60} value={name} onChange={(e) => setName(e.target.value)} /></div>
        <div><label className="label" htmlFor="l">{t("acc_lang")}</label>
          <select id="l" className="input" value={lang} onChange={(e) => setL(e.target.value as "so" | "en")}><option value="so">Soomaali</option><option value="en">English</option></select></div>
        {msg && <p className="alert-ok">{msg}</p>}{err && <p className="alert-err">{err}</p>}
        <button className="btn">{t("save")}</button>
      </form>
    </div>
  );
}
