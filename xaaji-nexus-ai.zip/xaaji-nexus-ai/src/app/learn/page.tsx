"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { useLang } from "@/lib/i18n";
import { useUser } from "@/lib/useUser";
import { supabaseBrowser } from "@/lib/supabase/client";

type L = { id: string; slug: string; title_so: string; title_en: string; desc_so: string; desc_en: string; steps_so: string[] };

export default function LearnPage() {
  const { t, lang } = useLang();
  const { user } = useUser();
  const [lessons, setLessons] = useState<L[] | null>(null);
  const [done, setDone] = useState<Record<string, number>>({});
  const [err, setErr] = useState("");

  useEffect(() => {
    const sb = supabaseBrowser();
    sb.from("lessons").select("id,slug,title_so,title_en,desc_so,desc_en,steps_so").eq("published", true).order("sort")
      .then(({ data, error }) => { if (error) setErr(t("error_generic")); else setLessons(data as L[]); });
  }, [t]);
  useEffect(() => {
    if (!user) return setDone({});
    supabaseBrowser().from("lesson_progress").select("lesson_id,completed_steps").then(({ data }) => {
      const m: Record<string, number> = {};
      (data ?? []).forEach((r) => { m[r.lesson_id] = r.completed_steps.length; });
      setDone(m);
    });
  }, [user]);

  return (
    <div className="page">
      <h1 className="h1 mb-5">📚 {t("nav_learn")}</h1>
      {err && <p className="alert-err">{err}</p>}
      {!lessons && !err && <p>{t("loading")}</p>}
      {lessons?.length === 0 && <p>{t("lessons_empty")}</p>}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {lessons?.map((l) => {
          const total = l.steps_so.length || 1;
          const pct = Math.round(((done[l.id] ?? 0) / total) * 100);
          return (
            <Link key={l.id} href={`/learn/${l.slug}`} className="card transition hover:border-nexus-violet hover:shadow-neon">
              <h2 className="font-head text-lg font-semibold">{lang === "so" ? l.title_so : l.title_en}</h2>
              <p className="mt-1 text-sm text-slate-300">{lang === "so" ? l.desc_so : l.desc_en}</p>
              <div className="mt-4 h-2 overflow-hidden rounded-full bg-nexus-bg" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
                <div className="h-full bg-gradient-to-r from-nexus-violet to-nexus-cyan" style={{ width: `${pct}%` }} />
              </div>
              <p className="mt-1 text-xs text-slate-400">{t("progress")}: {pct}%</p>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
