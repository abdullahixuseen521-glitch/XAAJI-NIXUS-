"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { useLang } from "@/lib/i18n";
import { useUser } from "@/lib/useUser";
import { supabaseBrowser } from "@/lib/supabase/client";
import Video from "@/components/Video";

type L = { id: string; title_so: string; title_en: string; desc_so: string; desc_en: string; steps_so: string[]; steps_en: string[]; video_url: string | null };

export default function LessonPage() {
  const { slug } = useParams<{ slug: string }>();
  const { t, lang } = useLang();
  const { user } = useUser();
  const sb = useMemo(() => supabaseBrowser(), []);
  const [lesson, setLesson] = useState<L | null>(null);
  const [missing, setMissing] = useState(false);
  const [doneSteps, setDoneSteps] = useState<number[]>([]);
  const [err, setErr] = useState("");

  useEffect(() => {
    sb.from("lessons").select("*").eq("slug", slug).eq("published", true).maybeSingle().then(({ data }) => {
      if (data) setLesson(data as L); else setMissing(true);
    });
  }, [sb, slug]);
  useEffect(() => {
    if (!user || !lesson) return;
    sb.from("lesson_progress").select("completed_steps").eq("lesson_id", lesson.id).maybeSingle().then(({ data }) => setDoneSteps(data?.completed_steps ?? []));
  }, [sb, user, lesson]);

  async function toggle(i: number) {
    if (!lesson) return;
    const next = doneSteps.includes(i) ? doneSteps.filter((x) => x !== i) : [...doneSteps, i];
    setDoneSteps(next);
    if (!user) return;
    const { error } = await sb.from("lesson_progress").upsert({ user_id: user.id, lesson_id: lesson.id, completed_steps: next, updated_at: new Date().toISOString() });
    setErr(error ? t("error_generic") : "");
  }

  if (missing) return <div className="page"><p>{t("lessons_empty")}</p><Link href="/learn" className="btn-ghost mt-3">{t("back")}</Link></div>;
  if (!lesson) return <div className="page">{t("loading")}</div>;
  const steps = lang === "so" ? lesson.steps_so : lesson.steps_en;
  const pct = steps.length ? Math.round((doneSteps.length / steps.length) * 100) : 0;

  return (
    <div className="page max-w-3xl">
      <Link href="/learn" className="text-sm text-nexus-cyan">← {t("back")}</Link>
      <h1 className="h1 mt-2">{lang === "so" ? lesson.title_so : lesson.title_en}</h1>
      <p className="mt-2 text-slate-300">{lang === "so" ? lesson.desc_so : lesson.desc_en}</p>
      {lesson.video_url && <div className="mt-5"><Video url={lesson.video_url} /></div>}
      <div className="card mt-5">
        <h2 className="font-head text-lg font-semibold">{t("steps")}</h2>
        <ul className="mt-3 space-y-2">
          {steps.map((s, i) => (
            <li key={i}>
              <label className="flex cursor-pointer items-start gap-3 rounded-lg p-2 hover:bg-white/5">
                <input type="checkbox" className="mt-1 h-4 w-4 accent-violet-500" checked={doneSteps.includes(i)} onChange={() => toggle(i)} />
                <span className={doneSteps.includes(i) ? "text-slate-400 line-through" : ""}>{s}</span>
              </label>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-sm text-slate-400">{t("progress")}: {pct}%</p>
        {!user && <p className="mt-2 text-sm">{t("login_to_save")} <Link className="underline" href="/login">{t("login")}</Link></p>}
        {err && <p className="alert-err mt-2">{err}</p>}
      </div>
    </div>
  );
}
