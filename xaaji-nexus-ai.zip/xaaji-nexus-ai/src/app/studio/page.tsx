"use client";
import Link from "next/link";
import { useState } from "react";
import { Copy } from "lucide-react";
import { Key, useLang } from "@/lib/i18n";

type Tab = "prompt" | "ideas" | "captions" | "descriptions";
const TABS: { id: Tab; k: Key }[] = [{ id: "prompt", k: "st_prompt" }, { id: "ideas", k: "st_ideas" }, { id: "captions", k: "st_captions" }, { id: "descriptions", k: "st_desc" }];
const STYLES = ["cinematic", "animated 3D", "documentary", "anime", "realistic social video"];

export default function StudioPage() {
  const { t, lang } = useLang();
  const [tab, setTab] = useState<Tab>("prompt");
  const [topic, setTopic] = useState("");
  const [chars, setChars] = useState("");
  const [place, setPlace] = useState("");
  const [voice, setVoice] = useState("Somali");
  const [style, setStyle] = useState(STYLES[0]);
  const [out, setOut] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [needLogin, setNeedLogin] = useState(false);
  const [copied, setCopied] = useState(false);

  async function generate(e: React.FormEvent) {
    e.preventDefault();
    setErr(""); setOut(""); setNeedLogin(false); setCopied(false);
    if (tab === "prompt") {
      setOut([
        `Create a 15-second vertical (9:16) ${style} video about: ${topic}.`,
        chars && `Characters: ${chars}.`,
        place && `Location: ${place}.`,
        `Opening: a strong visual hook in the first 2 seconds, then a clear middle and a satisfying ending.`,
        `Camera: slow push-in, then one wide establishing shot; smooth, stable movement.`,
        `Lighting and mood: rich colors with purple and blue tones, soft glow, high detail.`,
        `Voice-over and on-screen text language: ${voice}.`,
        `Avoid: distorted hands or faces, unreadable text, watermarks.`
      ].filter(Boolean).join("\n"));
      return;
    }
    setBusy(true);
    try {
      const content = `Topic: ${topic}${chars ? `\nPeople or characters: ${chars}` : ""}${place ? `\nLocation: ${place}` : ""}\nLanguage of the output: ${voice}`;
      const res = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode: tab, lang, messages: [{ role: "user", content }] })
      });
      const json = await res.json();
      if (res.status === 401) { setNeedLogin(true); return; }
      if (!res.ok) throw new Error(json.error || t("error_generic"));
      setOut(json.reply);
    } catch (e2) { setErr(e2 instanceof Error ? e2.message : t("error_generic")); } finally { setBusy(false); }
  }
  async function copy() { await navigator.clipboard.writeText(out); setCopied(true); }

  return (
    <div className="page max-w-3xl">
      <h1 className="h1 mb-4">🎬 {t("nav_studio")}</h1>
      <div className="mb-4 flex gap-2 overflow-x-auto" role="tablist">
        {TABS.map((x) => <button key={x.id} role="tab" aria-selected={tab === x.id} onClick={() => { setTab(x.id); setOut(""); setErr(""); setNeedLogin(false); }} className={tab === x.id ? "btn" : "btn-ghost"}>{t(x.k)}</button>)}
      </div>
      <form onSubmit={generate} className="card space-y-4">
        <p className="rounded-lg bg-nexus-violet/15 px-3 py-2 text-sm">{t("text_only")}{tab !== "prompt" && <> {t("ai_text_note")}</>}</p>
        <div><label className="label" htmlFor="topic">{t("topic")}</label><input id="topic" className="input" required maxLength={200} value={topic} onChange={(e) => setTopic(e.target.value)} /></div>
        <div className="grid gap-4 sm:grid-cols-2">
          <div><label className="label" htmlFor="chars">{t("characters")}</label><input id="chars" className="input" maxLength={200} value={chars} onChange={(e) => setChars(e.target.value)} /></div>
          <div><label className="label" htmlFor="place">{t("location")}</label><input id="place" className="input" maxLength={200} value={place} onChange={(e) => setPlace(e.target.value)} /></div>
          <div><label className="label" htmlFor="voice">{t("language")}</label>
            <select id="voice" className="input" value={voice} onChange={(e) => setVoice(e.target.value)}>{["Somali", "English", "Arabic"].map((v) => <option key={v}>{v}</option>)}</select></div>
          {tab === "prompt" && <div><label className="label" htmlFor="style">{t("style")}</label>
            <select id="style" className="input" value={style} onChange={(e) => setStyle(e.target.value)}>{STYLES.map((v) => <option key={v}>{v}</option>)}</select></div>}
        </div>
        <button className="btn" disabled={busy}>{busy ? t("loading") : t("generate")}</button>
      </form>
      {needLogin && <p className="alert-err mt-4">{t("need_login")} <Link className="underline" href="/login?next=/studio">{t("login")}</Link></p>}
      {err && <p className="alert-err mt-4">{err}</p>}
      {out && (
        <div className="card mt-4">
          <pre className="whitespace-pre-wrap font-body text-sm leading-relaxed">{out}</pre>
          <button onClick={copy} className="btn-ghost mt-3"><Copy size={15} />{copied ? t("copied") : t("copy")}</button>
        </div>
      )}
    </div>
  );
}
