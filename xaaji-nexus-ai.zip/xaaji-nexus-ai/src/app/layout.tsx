import "./globals.css";
import type { Metadata, Viewport } from "next";
import { Space_Grotesk, DM_Sans } from "next/font/google";
import { LangProvider } from "@/lib/i18n";
import Nav from "@/components/Nav";

const head = Space_Grotesk({ subsets: ["latin"], variable: "--font-head" });
const body = DM_Sans({ subsets: ["latin"], variable: "--font-body" });

export const metadata: Metadata = {
  title: "XAAJI NEXUS AI",
  description: "AI, games, learning and creator tools in Somali and English."
};
export const viewport: Viewport = { themeColor: "#07060f", width: "device-width", initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="so" className={`${head.variable} ${body.variable}`}>
      <body>
        <LangProvider>
          <Nav />
          <main>{children}</main>
        </LangProvider>
      </body>
    </html>
  );
}
