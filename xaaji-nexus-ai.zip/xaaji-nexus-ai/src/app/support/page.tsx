"use client";
import { useState } from "react";
import { MessageCircle } from "lucide-react";
import { useLang } from "@/lib/i18n";

const WA = (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "").replace(/\D/g, "");
const WA_OK = /^\d{8,15}$/.test(WA);

export default function SupportPage() {
  const { t } = useLang();
  const [f, setF] = useState({ name: "", email: "", message: "", website: "" });
  const [state, setState] = useState<"idle" | "sending" | "ok" | "err">("idle");
  const [err, setErr] = useState("");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setState("sending"); setErr("");
    try {
      const res = await fetch("/api/support", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || t("error_generic"));
      setState("ok"); setF({ name: "", email: "", message: "", website: "" });
    } catch (e2) { setErr(e2 instanceof Error ? e2.message : t("error_generic")); setState("err"); }
  }

  return (
    <div className="page max-w-xl">
      <h1 className="h1 mb-4">💬 {t("nav_support")}</h1>
      <form onSubmit={submit} className="card space-y-4" noValidate={false}>
        <div><label className="label" htmlFor="sn">{t("name")}</label><input id="sn" className="input" required minLength={2} maxLength={80} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
        <div><label className="label" htmlFor="se">{t("email")}</label><input id="se" type="email" className="input" required maxLength={120} value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
        <div><label className="label" htmlFor="sm">{t("sp_message")}</label><textarea id="sm" className="input min-h-32" required minLength={10} maxLength={2000} value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} /></div>
        <input className="hidden" tabIndex={-1} autoComplete="off" aria-hidden name="website" value={f.website} onChange={(e) => setF({ ...f, website: e.target.value })} />
        {state === "ok" && <p className="alert-ok" role="status">{t("sp_ok")}</p>}
        {state === "err" && <p className="alert-err" role="alert">{err}</p>}
        <button className="btn w-full" disabled={state === "sending"}>{state === "sending" ? t("sp_sending") : t("sp_send")}</button>
      </form>
      <div className="mt-4">
        {WA_OK ? (
          <a className="btn-ghost w-full" href={`https://wa.me/${WA}?text=${encodeURIComponent("XAAJI NEXUS AI")}`} target="_blank" rel="noopener noreferrer"><MessageCircle size={16} />{t("sp_whatsapp")}</a>
        ) : <p className="text-sm text-slate-400">{t("sp_wa_missing")}</p>}
      </div>
    </div>
  );
}
