import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseServer } from "@/lib/supabase/server";
import { AIConfigError, askClaude, systemPrompt } from "@/lib/ai";

const schema = z.object({
  mode: z.enum(["chat", "ideas", "captions", "descriptions"]),
  lang: z.enum(["so", "en"]),
  messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(4000) })).min(1).max(20)
});

export async function POST(req: Request) {
  const sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return NextResponse.json({ error: "Please log in first." }, { status: 401 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  const { mode, lang, messages } = parsed.data;
  if (messages[messages.length - 1].role !== "user") return NextResponse.json({ error: "Invalid request." }, { status: 400 });

  // Simple per-user rate limit: 10 AI calls per minute.
  const since = new Date(Date.now() - 60_000).toISOString();
  const { count } = await sb.from("ai_usage").select("id", { count: "exact", head: true }).gte("created_at", since);
  if ((count ?? 0) >= 10) return NextResponse.json({ error: "Too many requests. Wait a minute and try again." }, { status: 429 });
  await sb.from("ai_usage").insert({});

  try {
    const reply = await askClaude(systemPrompt(mode, lang), messages);
    return NextResponse.json({ reply });
  } catch (e) {
    if (e instanceof AIConfigError) return NextResponse.json({ error: "The AI service is not configured yet." }, { status: 503 });
    return NextResponse.json({ error: "The AI service is unavailable. Please try again." }, { status: 502 });
  }
}
