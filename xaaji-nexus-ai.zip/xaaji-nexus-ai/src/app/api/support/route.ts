import { NextResponse } from "next/server";
import { z } from "zod";
import { supabaseServer } from "@/lib/supabase/server";

const schema = z.object({
  name: z.string().trim().min(2).max(80),
  email: z.string().trim().email().max(120),
  message: z.string().trim().min(10).max(2000),
  website: z.string().max(0).optional() // honeypot: must stay empty
});

export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: "Please check your name, email and message (at least 10 characters).", fields: parsed.error.flatten().fieldErrors }, { status: 400 });
  }
  const { name, email, message } = parsed.data;
  const sb = await supabaseServer();
  const { error } = await sb.from("support_messages").insert({ name, email, message });
  if (error) return NextResponse.json({ error: "Your message could not be saved. Please try again or use WhatsApp." }, { status: 500 });
  return NextResponse.json({ ok: true });
}
