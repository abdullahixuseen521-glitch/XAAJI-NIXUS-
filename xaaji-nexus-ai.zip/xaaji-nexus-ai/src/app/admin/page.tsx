"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Key, useLang } from "@/lib/i18n";
import { supabaseBrowser } from "@/lib/supabase/client";

type Tab = "lessons" | "users" | "messages" | "content";
const TABS: { id: Tab; k: Key }[] = [{ id: "lessons", k: "ad_lessons" }, { id: "users", k: "ad_users" }, { id: "messages", k: "ad_messages" }, { id: "content", k: "ad_content" }];

type Lesson = { id: string; slug: string; category: string; title_so: string; title_en: string; desc_so: string; desc_en: string; steps_so: string[]; steps_en: string[]; video_url: string | null; sort: number; published: boolean };
type Form = Omit<Lesson, "id" | "steps_so" | "steps_en"> & { id?: string; steps_so: string; steps_en: string };
const blank: Form = { slug: "", category: "general", title_so: "", title_en: "", desc_so: "", desc_en: "", steps_so: "", steps_en: "", video_url: "", sort: 10, published: true };
type UserRow = { id: string; display_name: string | null; role: "user" | "admin"; created_at: string };
type Msg = { id: string; name: string; email: string; message: string; status: "new" | "read" | "done"; created_at: string };

export default function AdminPage() {
  const { t } = useLang();
  const sb = useMemo(() => supabaseBrowser(), []);
  const [tab, setTab] = useState<Tab>("lessons");
  const [err, setErr] = useState("");
  const [ok, setOk] = useState("");
  const [lessons, setLessons] = useState<Lesson[]>([]);
  const [form, setForm] = useState<Form | null>(null);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [me, setMe] = useState("");
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [welcome, setWelcome] = useState({ so: "", en: "" });

  const fail = () => { setErr(t("error_generic")); setOk(""); };
  const done = () => { setOk(t("saved")); setErr(""); };

  const load = useCallback(async () => {
    const { data: u } = await sb.auth.getUser(); setMe(u.user?.id ?? "");
    if (tab === "lessons") { const { data, error } = await sb.from("lessons").select("*").order("sort"); error ? fail() : setLessons(data as Lesson[]); }
    if (tab === "users") { const { data, error } = await sb.from("profiles").select("id,display_name,role,created_at").order("created_at", { ascending: false }); error ? fail() : setUsers(data as UserRow[]); }
    if (tab === "messages") { const { data, error } = await sb.from("support_messages").select("*").order("created_at", { ascending: false }); error ? fail() : setMsgs(data as Msg[]); }
    if (tab === "content") { const { data } = await sb.from("site_content").select("value_so,value_en").eq("key", "welcome").maybeSingle(); if (data) setWelcome({ so: data.value_so, en: data.value_en }); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sb, tab]);
  useEffect(() => { load(); }, [load]);

  async function saveLesson(e: React.FormEvent) {
    e.preventDefault(); if (!form) return;
    const lines = (s: string) => s.split("\n").map((x) => x.trim()).filter(Boolean);
    const video = form.video_url?.trim() || null;
    if (!/^[a-z0-9-]+$/.test(form.slug)) return setErr("Slug: lowercase letters, numbers and dashes only.");
    if (video && !video.startsWith("https://")) return setErr("Video URL must start with https://");
    const { id, steps_so, steps_en, ...rest } = form;
    const row = { ...rest, video_url: video, steps_so: lines(steps_so), steps_en: lines(steps_en) };
    const { error } = id ? await sb.from("lessons").update(row).eq("id", id) : await sb.from("lessons").insert(row);
    if (error) return fail();
    setForm(null); done(); load();
  }
  async function delLesson(id: string) { const { error } = await sb.from("lessons").delete().eq("id", id); error ? fail() : (done(), load()); }
  async function setRole(id: string, role: "user" | "admin") { const { error } = await sb.from("profiles").update({ role }).eq("id", id); error ? fail() : (done(), load()); }
  async function setStatus(id: string, status: string) { const { error } = await sb.from("support_messages").update({ status }).eq("id", id); error ? fail() : load(); }
  async function delMsg(id: string) { const { error } = await sb.from("support_messages").delete().eq("id", id); error ? fail() : load(); }
  async function saveWelcome(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await sb.from("site_content").upsert({ key: "welcome", value_so: welcome.so, value_en: welcome.en, updated_at: new Date().toISOString() });
    error ? fail() : done();
  }
  const edit = (l: Lesson) => setForm({ ...l, steps_so: l.steps_so.join("\n"), steps_en: l.steps_en.join("\n") });
  const set = (k: keyof Form, v: string | number | boolean) => setForm((f) => (f ? { ...f, [k]: v } : f));

  return (
    <div className="page">
      <h1 className="h1 mb-4">⚙️ {t("nav_admin")}</h1>
      <div className="mb-4 flex gap-2 overflow-x-auto" role="tablist">
        {TABS.map((x) => <button key={x.id} role="tab" aria-selected={tab === x.id} onClick={() => { setTab(x.id); setErr(""); setOk(""); setForm(null); }} className={tab === x.id ? "btn" : "btn-ghost"}>{t(x.k)}</button>)}
      </div>
      {err && <p className="alert-err mb-3">{err}</p>}{ok && <p className="alert-ok mb-3">{ok}</p>}

      {tab === "lessons" && (
        <>
          <button className="btn mb-4" onClick={() => setForm(blank)}>{t("n_new")}</button>
          {form && (
            <form onSubmit={saveLesson} className="card mb-5 grid gap-3 sm:grid-cols-2">
              {(["slug", "category", "title_so", "title_en", "video_url"] as const).map((k) => (
                <div key={k}><label className="label">{k}</label><input className="input" required={k !== "video_url"} value={(form[k] as string) ?? ""} onChange={(e) => set(k, e.target.value)} /></div>
              ))}
              <div><label className="label">sort</label><input type="number" className="input" value={form.sort} onChange={(e) => set("sort", Number(e.target.value))} /></div>
              {(["desc_so", "desc_en", "steps_so", "steps_en"] as const).map((k) => (
                <div key={k}><label className="label">{k}{k.startsWith("steps") ? " (one per line)" : ""}</label><textarea className="input min-h-24" value={form[k]} onChange={(e) => set(k, e.target.value)} /></div>
              ))}
              <label className="flex items-center gap-2"><input type="checkbox" checked={form.published} onChange={(e) => set("published", e.target.checked)} />published</label>
              <div className="flex gap-2 sm:col-span-2"><button className="btn">{t("save")}</button><button type="button" className="btn-ghost" onClick={() => setForm(null)}>{t("cancel")}</button></div>
            </form>
          )}
          <div className="space-y-2">
            {lessons.map((l) => (
              <div key={l.id} className="card flex flex-wrap items-center justify-between gap-2 !p-3">
                <span>{l.title_en} <span className="text-xs text-slate-400">/{l.slug} {l.published ? "" : "(draft)"}</span></span>
                <span className="flex gap-2"><button className="btn-ghost text-sm" onClick={() => edit(l)}>{t("edit")}</button><button className="btn-ghost text-sm" onClick={() => delLesson(l.id)}>{t("delete")}</button></span>
              </div>
            ))}
          </div>
        </>
      )}

      {tab === "users" && (
        <div className="space-y-2">
          {users.map((u) => (
            <div key={u.id} className="card flex items-center justify-between gap-2 !p-3">
              <span>{u.display_name || "(no name)"} <span className="text-xs text-slate-400">{new Date(u.created_at).toLocaleDateString()}</span></span>
              <select className="input !w-auto" value={u.role} disabled={u.id === me} onChange={(e) => setRole(u.id, e.target.value as "user" | "admin")} aria-label="role">
                <option value="user">user</option><option value="admin">admin</option>
              </select>
            </div>
          ))}
        </div>
      )}

      {tab === "messages" && (
        <div className="space-y-3">
          {msgs.length === 0 && <p className="text-slate-400">{t("empty")}</p>}
          {msgs.map((m) => (
            <div key={m.id} className="card">
              <p className="text-sm text-slate-400">{m.name} · {m.email} · {new Date(m.created_at).toLocaleString()}</p>
              <p className="mt-2 whitespace-pre-wrap">{m.message}</p>
              <div className="mt-3 flex gap-2">
                <select className="input !w-auto" value={m.status} onChange={(e) => setStatus(m.id, e.target.value)}><option>new</option><option>read</option><option>done</option></select>
                <button className="btn-ghost text-sm" onClick={() => delMsg(m.id)}>{t("delete")}</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "content" && (
        <form onSubmit={saveWelcome} className="card max-w-2xl space-y-3">
          <div><label className="label">Welcome (Somali)</label><textarea className="input min-h-24" required value={welcome.so} onChange={(e) => setWelcome({ ...welcome, so: e.target.value })} /></div>
          <div><label className="label">Welcome (English)</label><textarea className="input min-h-24" required value={welcome.en} onChange={(e) => setWelcome({ ...welcome, en: e.target.value })} /></div>
          <button className="btn">{t("save")}</button>
        </form>
      )}
    </div>
  );
}
