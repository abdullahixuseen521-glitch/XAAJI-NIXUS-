import { redirect } from "next/navigation";
import { supabaseServer } from "@/lib/supabase/server";

// Server-side guard. Data access is ALSO enforced by Postgres Row Level Security (is_admin()).
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const sb = await supabaseServer();
  const { data: { user } } = await sb.auth.getUser();
  if (!user) redirect("/login?next=/admin");
  const { data: p } = await sb.from("profiles").select("role").eq("id", user.id).single();
  if (p?.role !== "admin") redirect("/");
  return <>{children}</>;
}
