"use client";
import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Key, useLang } from "@/lib/i18n";
import { useUser } from "@/lib/useUser";
import { supabaseBrowser } from "@/lib/supabase/client";
import TicTacToe from "@/components/games/TicTacToe";
import Memory from "@/components/games/Memory";
import Snake from "@/components/games/Snake";

type G = "ttt" | "memory" | "snake";
const TABS: { id: G; k: Key }[] = [{ id: "ttt", k: "g_ttt" }, { id: "memory", k: "g_memory" }, { id: "snake", k: "g_snake" }];
type Row = { user_id: string; display_name: string | null; best: number };

export default function GamesPage() {
  const { t } = useLang();
  const { user } = useUser();
  const sb = useMemo(() => supabaseBrowser(), []);
  const [tab, setTab] = useState<G>("ttt");
  const [msg, setMsg] = useState("");
  const [rows, setRows] = useState<Row[]>([]);
  const [rev, setRev] = useState(0);

  const loadBoard = useCallback(async () => {
    if (tab === "ttt") return setRows([]);
    const { data } = await sb.from("leaderboard").select("user_id,display_name,best").eq("game", tab).order("best", { ascending: false }).limit(10);
    setRows((data as Row[]) ?? []);
  }, [sb, tab]);
  useEffect(() => { loadBoard(); }, [loadBoard, rev]);
  useEffect(() => { setMsg(""); }, [tab]);

  const finish = useCallback(async (score: number) => {
    if (tab === "ttt" || score <= 0) return;
    if (!user) return setMsg(t("login_to_save"));
    const { error } = await sb.from("scores").insert({ game: tab, score });
    if (error) setMsg(t("error_generic")); else { setMsg(t("score_saved")); setRev((r) => r + 1); }
  }, [sb, tab, user, t]);

  return (
    <div className="page">
      <h1 className="h1 mb-4">🎮 {t("nav_games")}</h1>
      <div className="mb-5 flex gap-2 overflow-x-auto" role="tablist">
        {TABS.map((x) => (
          <button key={x.id} role="tab" aria-selected={tab === x.id} onClick={() => setTab(x.id)} className={tab === x.id ? "btn" : "btn-ghost"}>{t(x.k)}</button>
        ))}
      </div>
      <div className="grid gap-5 lg:grid-cols-[1fr_300px]">
        <div className="card">
          {tab === "ttt" && <TicTacToe />}
          {tab === "memory" && <Memory onFinish={finish} />}
          {tab === "snake" && <Snake onFinish={finish} />}
          {msg && <p className="alert-ok mt-4 text-center">{msg}{!user && <> <Link href="/login" className="underline">{t("login")}</Link></>}</p>}
        </div>
        <aside className="card">
          <h2 className="mb-3 font-head text-lg font-semibold">{t("leaderboard")}</h2>
          {tab === "ttt" ? <p className="text-sm text-slate-400">{t("score")}: session</p> : rows.length === 0 ? <p className="text-sm text-slate-400">{t("no_scores")}</p> : (
            <ol className="space-y-1.5 text-sm">
              {rows.map((r, i) => (
                <li key={r.user_id} className="flex justify-between rounded-lg bg-nexus-bg/60 px-3 py-2"><span>{i + 1}. {r.display_name || "Player"}</span><b>{r.best}</b></li>
              ))}
            </ol>
          )}
        </aside>
      </div>
    </div>
  );
}
