"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { BookOpen, Bot, Clapperboard, Gamepad2, LifeBuoy, NotebookPen } from "lucide-react";
import { Key, useLang } from "@/lib/i18n";
import { supabaseBrowser } from "@/lib/supabase/client";

const FEATURES: { href: string; icon: typeof Bot; title: Key; desc: Key }[] = [
  { href: "/chat", icon: Bot, title: "nav_chat", desc: "feat_chat" },
  { href: "/games", icon: Gamepad2, title: "nav_games", desc: "feat_games" },
  { href: "/learn", icon: BookOpen, title: "nav_learn", desc: "feat_learn" },
  { href: "/studio", icon: Clapperboard, title: "nav_studio", desc: "feat_studio" },
  { href: "/notes", icon: NotebookPen, title: "nav_notes", desc: "feat_notes" },
  { href: "/support", icon: LifeBuoy, title: "nav_support", desc: "feat_support" }
];

export default function Home() {
  const { t, lang } = useLang();
  const [custom, setCustom] = useState<{ so: string; en: string } | null>(null);

  useEffect(() => {
    try {
      supabaseBrowser().from("site_content").select("value_so,value_en").eq("key", "welcome").maybeSingle()
        .then(({ data }) => { if (data?.value_so) setCustom({ so: data.value_so, en: data.value_en }); });
    } catch { /* falls back to default text */ }
  }, []);

  return (
    <div className="page">
      <section className="relative overflow-hidden rounded-3xl border border-nexus-line bg-nexus-panel/60 px-6 py-14 text-center sm:py-20">
        <div aria-hidden className="orb pointer-events-none absolute left-1/2 top-1/2 h-[34rem] w-[34rem] -translate-x-1/2 -translate-y-1/2 rounded-full opacity-30 blur-3xl"
          style={{ background: "conic-gradient(from 0deg, #8b5cf6, #2f6bff, #22d3ee, #8b5cf6)" }} />
        <div className="relative">
          <h1 className="font-head text-4xl font-bold tracking-wide logo-glow sm:text-6xl">XAAJI NEXUS AI</h1>
          <p className="mx-auto mt-5 max-w-2xl text-base text-slate-200 sm:text-lg">{custom ? custom[lang] : t("welcome_default")}</p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link href="/chat" className="btn">{t("hero_cta_chat")}</Link>
            <Link href="/games" className="btn-ghost">{t("hero_cta_games")}</Link>
          </div>
        </div>
      </section>

      <section className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {FEATURES.map(({ href, icon: Icon, title, desc }) => (
          <Link key={href} href={href} className="card group transition hover:border-nexus-violet hover:shadow-neon">
            <Icon className="text-nexus-cyan" size={26} />
            <h2 className="mt-3 font-head text-lg font-semibold">{t(title)}</h2>
            <p className="mt-1 text-sm text-slate-300">{t(desc)}</p>
          </Link>
        ))}
      </section>
    </div>
  );
}
