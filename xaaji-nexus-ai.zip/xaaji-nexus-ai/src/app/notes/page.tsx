"use client";
import { useEffect, useMemo, useState } from "react";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { Key, useLang } from "@/lib/i18n";
import { supabaseBrowser } from "@/lib/supabase/client";

const CATS = ["personal", "school", "work", "ideas"] as const;
type Cat = (typeof CATS)[number];
const CAT_KEY: Record<Cat, Key> = { personal: "c_personal", school: "c_school", work: "c_work", ideas: "c_ideas" };
type Note = { id: string; title: string; body: string; category: Cat; updated_at: string };
type Draft = { id?: string; title: string; body: string; category: Cat };

export default function NotesPage() {
  const { t, lang } = useLang();
  const sb = useMemo(() => supabaseBrowser(), []);
  const [notes, setNotes] = useState<Note[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<"all" | Cat>("all");
  const [draft, setDraft] = useState<Draft | null>(null);
  const [err, setErr] = useState("");

  async function load() {
    const { data, error } = await sb.from("notes").select("id,title,body,category,updated_at").order("updated_at", { ascending: false });
    if (error) setErr(t("error_generic")); else setNotes(data as Note[]);
    setLoading(false);
  }
  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  const shown = notes.filter((n) => (cat === "all" || n.category === cat) && `${n.title} ${n.body}`.toLowerCase().includes(q.toLowerCase()));

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!draft) return;
    setErr("");
    const row = { title: draft.title.trim(), body: draft.body, category: draft.category, updated_at: new Date().toISOString() };
    const { error } = draft.id ? await sb.from("notes").update(row).eq("id", draft.id) : await sb.from("notes").insert(row);
    if (error) return setErr(t("error_generic"));
    setDraft(null); load();
  }
  async function remove(id: string) {
    const { error } = await sb.from("notes").delete().eq("id", id);
    if (error) setErr(t("error_generic")); else setNotes((n) => n.filter((x) => x.id !== id));
  }

  return (
    <div className="page">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h1 className="h1">📝 {t("nav_notes")}</h1>
        <button className="btn" onClick={() => setDraft({ title: "", body: "", category: "personal" })}><Plus size={16} />{t("n_new")}</button>
      </div>
      <div className="mb-4 grid gap-3 sm:grid-cols-[1fr_200px]">
        <input className="input" placeholder={t("search")} value={q} onChange={(e) => setQ(e.target.value)} aria-label={t("search")} />
        <select className="input" value={cat} onChange={(e) => setCat(e.target.value as "all" | Cat)} aria-label={t("n_category")}>
          <option value="all">{t("all")}</option>{CATS.map((c) => <option key={c} value={c}>{t(CAT_KEY[c])}</option>)}
        </select>
      </div>
      {err && <p className="alert-err mb-3">{err}</p>}
      {draft && (
        <form onSubmit={save} className="card mb-5 space-y-3">
          <div><label className="label" htmlFor="nt">{t("n_title")}</label><input id="nt" className="input" required maxLength={120} value={draft.title} onChange={(e) => setDraft({ ...draft, title: e.target.value })} /></div>
          <div><label className="label" htmlFor="nb">{t("n_body")}</label><textarea id="nb" className="input min-h-32" maxLength={10000} value={draft.body} onChange={(e) => setDraft({ ...draft, body: e.target.value })} /></div>
          <div><label className="label" htmlFor="nc">{t("n_category")}</label>
            <select id="nc" className="input" value={draft.category} onChange={(e) => setDraft({ ...draft, category: e.target.value as Cat })}>{CATS.map((c) => <option key={c} value={c}>{t(CAT_KEY[c])}</option>)}</select></div>
          <div className="flex gap-2"><button className="btn">{t("save")}</button><button type="button" className="btn-ghost" onClick={() => setDraft(null)}>{t("cancel")}</button></div>
        </form>
      )}
      {loading ? <p>{t("loading")}</p> : shown.length === 0 ? <p className="text-slate-400">{t("empty")}</p> : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((n) => (
            <article key={n.id} className="card">
              <div className="flex items-start justify-between gap-2">
                <h2 className="font-head font-semibold">{n.title}</h2>
                <span className="rounded-full bg-nexus-violet/20 px-2 py-0.5 text-xs">{t(CAT_KEY[n.category])}</span>
              </div>
              <p className="mt-2 line-clamp-5 whitespace-pre-wrap text-sm text-slate-300">{n.body}</p>
              <p className="mt-3 text-xs text-slate-500">{t("updated")}: {new Date(n.updated_at).toLocaleString(lang === "so" ? "so-SO" : "en-US")}</p>
              <div className="mt-3 flex gap-2">
                <button className="btn-ghost text-sm" onClick={() => setDraft({ id: n.id, title: n.title, body: n.body, category: n.category })}><Pencil size={14} />{t("edit")}</button>
                <button className="btn-ghost text-sm" onClick={() => remove(n.id)} aria-label={t("delete")}><Trash2 size={14} /></button>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
