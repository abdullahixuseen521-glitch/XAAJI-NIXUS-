-- XAAJI NEXUS AI - run this whole file once in Supabase > SQL Editor.
create extension if not exists pgcrypto;

-- ===== profiles & roles =====
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text check (char_length(display_name) <= 60),
  role text not null default 'user' check (role in ('user','admin')),
  lang text not null default 'so' check (lang in ('so','en')),
  created_at timestamptz not null default now()
);

create or replace function public.is_admin() returns boolean
language sql security definer stable set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
$$;

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name)
  values (new.id, left(coalesce(new.raw_user_meta_data->>'display_name',''), 60));
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create or replace function public.protect_role() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.role is distinct from old.role and auth.uid() is not null and not public.is_admin() then
    raise exception 'role change not allowed';
  end if;
  return new;
end $$;
create trigger profiles_protect_role before update on public.profiles
  for each row execute function public.protect_role();

alter table public.profiles enable row level security;
create policy "profiles read own or admin" on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy "profiles update own" on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());
create policy "profiles admin update" on public.profiles for update using (public.is_admin()) with check (public.is_admin());

-- ===== site content (editable by admins) =====
create table public.site_content (
  key text primary key, value_so text not null default '', value_en text not null default '',
  updated_at timestamptz not null default now()
);
alter table public.site_content enable row level security;
create policy "content read" on public.site_content for select using (true);
create policy "content admin write" on public.site_content for all using (public.is_admin()) with check (public.is_admin());

-- ===== lessons & progress =====
create table public.lessons (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null check (slug ~ '^[a-z0-9-]+$'),
  category text not null default 'general',
  title_so text not null, title_en text not null,
  desc_so text not null default '', desc_en text not null default '',
  steps_so jsonb not null default '[]', steps_en jsonb not null default '[]',
  video_url text check (video_url is null or video_url ~ '^https://'),
  sort int not null default 0, published boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.lessons enable row level security;
create policy "lessons read published" on public.lessons for select using (published or public.is_admin());
create policy "lessons admin write" on public.lessons for all using (public.is_admin()) with check (public.is_admin());

create table public.lesson_progress (
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  lesson_id uuid not null references public.lessons(id) on delete cascade,
  completed_steps int[] not null default '{}',
  updated_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);
alter table public.lesson_progress enable row level security;
create policy "progress own" on public.lesson_progress for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ===== chat =====
create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title text not null default 'New chat', created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  role text not null check (role in ('user','assistant')),
  content text not null check (char_length(content) <= 20000),
  created_at timestamptz not null default now()
);
create table public.ai_usage (
  id bigint generated always as identity primary key,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.ai_usage enable row level security;
create policy "conv own" on public.conversations for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "msg own" on public.messages for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "usage own" on public.ai_usage for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ===== notes =====
create table public.notes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  body text not null default '' check (char_length(body) <= 10000),
  category text not null default 'personal' check (category in ('personal','school','work','ideas')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
alter table public.notes enable row level security;
create policy "notes own" on public.notes for all using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ===== game scores (bounded by constraints; see README note on cheating) =====
create table public.scores (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  display_name text,
  game text not null check (game in ('snake','memory')),
  score int not null check (score >= 0),
  created_at timestamptz not null default now(),
  constraint scores_range check ((game = 'snake' and score <= 2600) or (game = 'memory' and score <= 1000))
);
create or replace function public.set_score_name() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  new.display_name := coalesce((select nullif(display_name,'') from public.profiles where id = new.user_id), 'Player');
  return new;
end $$;
create trigger scores_set_name before insert on public.scores for each row execute function public.set_score_name();
alter table public.scores enable row level security;
create policy "scores insert own" on public.scores for insert with check (user_id = auth.uid());
create policy "scores read own" on public.scores for select using (user_id = auth.uid());
create view public.leaderboard as
  select game, user_id, display_name, max(score) as best from public.scores group by game, user_id, display_name;
grant select on public.leaderboard to anon, authenticated;

-- ===== support messages =====
create table public.support_messages (
  id uuid primary key default gen_random_uuid(),
  user_id uuid default auth.uid(),
  name text not null check (char_length(name) between 2 and 80),
  email text not null check (email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$' and char_length(email) <= 120),
  message text not null check (char_length(message) between 10 and 2000),
  status text not null default 'new' check (status in ('new','read','done')),
  created_at timestamptz not null default now()
);
alter table public.support_messages enable row level security;
create policy "support insert" on public.support_messages for insert to anon, authenticated with check (true);
create policy "support admin read" on public.support_messages for select using (public.is_admin());
create policy "support admin update" on public.support_messages for update using (public.is_admin()) with check (public.is_admin());
create policy "support admin delete" on public.support_messages for delete using (public.is_admin());

-- ===== seed content =====
insert into public.site_content (key, value_so, value_en) values ('welcome',
 'ASC! Ku soo dhawoow XAAJI NEXUS AI 🚀 Halkaan waxaad ka heli kartaa AI, ciyaaro, waxbarasho iyo qalab kaa caawinaya inaad fikradahaaga u beddesho wax dhab ah.',
 'Welcome to XAAJI NEXUS AI 🚀 Here you will find AI, games, learning and tools that help you turn your ideas into real things.');

insert into public.lessons (slug, category, sort, title_so, title_en, desc_so, desc_en, steps_so, steps_en) values
('video-editing','video',1,'Tafatirka Muuqaalka','Video Editing',
 'Baro sida loo gooyo, loo isku xiro oo loo dhammeeyo muuqaal gaaban.','Learn to cut, join and finish a short video.',
 '["Dooro app tafatir (CapCut ama DaVinci Resolve)","Soo geli muuqaalada oo u habee timeline-ka","Goo qaybaha aan loo baahnayn oo ku dar musig iyo qoraal","Soo saar muuqaalka 1080p oo la wadaag"]',
 '["Pick an editing app (CapCut or DaVinci Resolve)","Import your clips and arrange them on the timeline","Trim unwanted parts and add music and text","Export in 1080p and share"]'),
('ai-prompts','ai',2,'AI iyo Qoritaanka Prompts','AI Tools and Prompt Writing',
 'Baro sida loo weydiiyo AI si aad u hesho jawaab fiican.','Learn how to ask AI so you get better answers.',
 '["Sheeg hadafka si cad: maxaad rabtaa?","Ku dar xaalada: cidda, goobta iyo qaabka","Codso qaab soo-saar gaar ah: liis, jadwal ama koodh","Hagaaji jawaabta adigoo weydiinaya weydiimo dheeraad ah"]',
 '["State your goal clearly: what do you want?","Add context: audience, place and style","Ask for a specific output format: list, table or code","Refine the answer with follow-up questions"]'),
('web-development','code',3,'Horumarinta Website-ka','Website Development',
 'Fahan HTML, CSS iyo JavaScript oo samee bog koowaad.','Understand HTML, CSS and JavaScript and build your first page.',
 '["Baro HTML: cinwaan, qoraal, sawir iyo isku-xirid","Baro CSS: midab, qaab-dhismeed iyo shaashad yar","Ku dar JavaScript si badhamadu u shaqeeyaan","Geli koodhka GitHub oo ku daabac Vercel"]',
 '["Learn HTML: headings, text, images and links","Learn CSS: colors, layout and small screens","Add JavaScript so buttons do something","Push your code to GitHub and publish on Vercel"]'),
('graphic-design','design',4,'Naqshadaynta Garaafiga','Graphic Design',
 'Baro midabada, farta iyo habaynta si aad u samayso naqshad nadiif ah.','Learn color, type and layout to make clean designs.',
 '["Dooro 2-3 midab oo is-leh","Dooro hal ama laba far oo si fudud loo akhriyo","U habee walxaha adigoo isticmaalaya meel bannaan","Ku tijaabi shaashad yar kahor inaad dhammeyso"]',
 '["Pick 2-3 colors that work together","Choose one or two easy-to-read fonts","Arrange elements using white space","Test on a small screen before you finish"]'),
('programming-basics','code',5,'Barnaamijka Aasaaska ah','Basic Programming',
 'Baro doorsoomayaasha, shuruudaha iyo dhuumaha (loops).','Learn variables, conditions and loops.',
 '["Fahan doorsoome (variable) iyo noocyada xogta","Isticmaal if/else si koodhku u doorto jid","Isticmaal loops si aad hawl u celiso","Qor mashruuc yar, tusaale xisaabiye fudud"]',
 '["Understand variables and data types","Use if/else so code can choose a path","Use loops to repeat work","Write a small project, such as a simple calculator"]');
